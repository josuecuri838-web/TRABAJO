LIMPIEZA QUE HACE LA DIFERENCIA - V1

Incluye:
- Inicio y registro con guardado local.
- Menú con secciones desplegables.
- Video demostrativo y reproductor.
- 10 materiales de limpieza con su uso.
- Sección informativa sobre higiene y prevención.
- Encuesta interactiva.
- Perfil con los datos registrados.
- Diseño responsive para celular.
- Manifest + Service Worker para instalación como PWA cuando se sirva desde HTTPS/localhost.

Uso:
1. Descomprime el ZIP.
2. Abre index.html para probar la app.
3. Para que la instalación PWA y el video funcionen de forma más consistente, sirve la carpeta desde un servidor local o HTTPS.
4. El archivo video-limpieza-demo.mp4 puede reemplazarse por el video real del proyecto conservando ese mismo nombre.
